<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class globalCommision extends Model
{
     protected $fillable = [
        'percentage',
    ];
}
