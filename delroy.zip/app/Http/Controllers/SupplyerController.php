<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\shop;
use Auth;

class SupplyerController extends Controller
{

    public function index(){
        return view('supplier.index');
    }

    public function shops(){
        $shops = auth::user()->shops;
        
        return view('supplier.shops.index')
        ->with('shops',$shops);
    }

    public function shopOrders(){
        $shops = auth::user()->shops;
        if($shops == !null){
            $orderItems = $shops->order_items;
        }else{
            $orderItems = [];

        }

        
        
        // return $orderItems;
       return view('supplier.orders.index')
       ->with('orderItems',$orderItems);
    }
    
    public function settings(){
        return view('supplier.settings');
    }
}
