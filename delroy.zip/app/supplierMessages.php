<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class supplierMessages extends Model
{
    //
}
