<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class temporaryAddress extends Model
{
    //
}
