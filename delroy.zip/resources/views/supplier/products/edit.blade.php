@extends('layouts.supply')
@section('content')
{{$product}}

<form></form>
@endsection