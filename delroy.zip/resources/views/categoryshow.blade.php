@extends('layouts.front2')
@section('content')

@endsection