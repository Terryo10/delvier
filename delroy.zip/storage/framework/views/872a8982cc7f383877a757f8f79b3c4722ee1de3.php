
<?php $__env->startSection('content'); ?>

    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('commision.update',$results->id)); ?>">
      <?php echo e(method_field('PATCH')); ?>

      <?php echo e(csrf_field()); ?>

            <div class="form-group">
               <div class="form-group">
          <label for="exampleFormControlSelect2"> Current Percentage is <?php echo e($results->percentage); ?>

            <div class="form-group">
             <label for="exampleFormControlInput1">Category Name</label>
                <input type="number" name="percentage" class="form-control" id="exampleFormControlInput1" placeholder="<?php echo e($results->percentage); ?> %" required=""> 
                </div>
        <label for="exampleFormControlSelect2">Edit here</label>
      
        </div>
        <div>
            <button class="btn btn-primary" type="submit">Update</button>
        </div>
            </div>
        <hr>
       
    </form>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.adminlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/admin/commision/edit.blade.php ENDPATH**/ ?>