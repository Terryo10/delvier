
<?php $__env->startSection('content'); ?>
<!-- Stats -->
                    <div class="outer-w3-agile col-xl">
                        <div class="stat-grid p-3 d-flex align-items-center justify-content-between bg-primary">
                            <div class="s-l">
                            <h5><?php echo e(auth::user()->name); ?></h5>
                                <p class="paragraph-agileits-w3layouts text-white">WELCOME TO SUPPLIERS DASHBOARD</p>
                            </div>
                            <div class="s-r">
                                <h6>
                                    <i class="far fa-edit"></i>
                                </h6>
                            </div>
                        </div>
                       
                       
                    </div>
                    <!--// Stats -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.supply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/supplier/index.blade.php ENDPATH**/ ?>