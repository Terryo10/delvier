
<?php $__env->startSection('content'); ?>

Customise comision Percentage
<br>
<p>N.B do not create 2 commisions</p>
<a href="/commision/create"><button class="btn btn-success">Create Commision</button></a>



             <!-- table3 -->
                <div class="outer-w3-agile mt-3">
                    <h4 class="tittle-w3-agileits mb-4">Commision</h4>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Commision ID</th>
                               
                                 <th scope="col">Active Pecentage</th>
                                 <th scope="col">Action</th>
                                 
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $commision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <th scope="row"><?php echo e($items->id); ?></th>
                            <td><?php echo e($items->percentage); ?> %</td>
                            <td><a href="/commision/<?php echo e($items->id); ?>/edit"><button class="btn btn-danger" >Edit </button></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!--// table3 -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/admin/commision/index.blade.php ENDPATH**/ ?>