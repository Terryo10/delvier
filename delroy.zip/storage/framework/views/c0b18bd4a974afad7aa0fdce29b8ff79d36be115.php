
<?php $__env->startSection('content'); ?>
<?php echo e($product); ?>


<form></form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.supply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/supplier/products/edit.blade.php ENDPATH**/ ?>