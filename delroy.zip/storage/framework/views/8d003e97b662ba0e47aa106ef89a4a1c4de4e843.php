
<?php $__env->startSection('content'); ?>

     
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Order <?php echo e($order->id); ?></li>
                    </ol>
                </div><!-- End .container -->
            </nav>

            <div class="container">
                <div class="row">
                    <div class="col-lg-9 order-lg-last dashboard-content">
                    <h2>Order <?php echo e($order->id); ?></h2>


                        <div class="mb-4"></div><!-- margin -->

                        <h3></h3>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        Order Information
                                      
                                    </div><!-- End .card-header -->

                                    <div class="card-body">
                                      
                                          <h3>ORDER REF: <?php echo e($order->id); ?></h3>
                                            <p>
                                            CREATED ON: <?php echo e($order->created_at); ?><br>
                                            PAYMENT STATUS: <?php echo e($order->paymentStatus); ?><br>
                                            TRANSACTION REF: <?php echo e($order->transaction_ref); ?><br>
                                            ORDER STATUS: <?php echo e($order->status); ?>

                                            <br>
                                            <br>
                                            <br>
                                          
                                            </p>
                                        
                                    </div><!-- End .card-body -->
                                </div><!-- End .card -->
                            </div><!-- End .col-md-6 -->

                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        Delivery Information
                                     
                                    </div><!-- End .card-header -->

                                    <div class="card-body">
                                        <h3>Address: <?php echo e($delivery->address); ?></h3>
                                        <p>Country: <?php echo e($delivery->country); ?>

                                        <br>City: <?php echo e($delivery->city); ?>

                                        <br>Phone: <?php echo e($delivery->phone); ?>

                                        <br>Firstname: <?php echo e($delivery->firstname); ?>

                                        <br>Lastname: <?php echo e($delivery->lastname); ?>

                                    </p>
                                    </div><!-- End .card-body -->
                                </div><!-- End .card -->
                            </div><!-- End .col-md-6 -->
                        </div><!-- End .row -->

                        <div class="card">
                            <div class="card-header">
                                Products In Order
                                <a href="#" class="card-edit">Edit</a>
                            </div><!-- End .card-header -->

        <div class="card-body">
                        <div class="row">
                        <table class="table" id="myTable">
                        <thead>
                            <tr>
                               
                                <th scope="col">Ordered Item</th>
                                <th scope="col">Price</th>
                                <th scope="col">QTY Orderd</th>
                                <th scope="col">Paid</th>
                                 <th scope="col">Status</th>
                                
                                
                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                
                                <td><?php echo e($item->product->name); ?></td>
                                <td>$<?php echo e($item->product->price); ?></td>
                                <td>X <?php echo e($item->quantity); ?></td>
                                <td>$<?php echo e($item->quantity*$item->product->price); ?></td>
                                <td><?php echo e($item->status); ?></td>
                              
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                        </table>
                                    
                        </div>
    </div><!-- End .card-body -->
                        </div><!-- End .card -->
                    </div><!-- End .col-lg-9 -->

                    <aside class="sidebar col-lg-3">
                        <div class="widget widget-dashboard">
                            <h3 class="widget-title">My Account</h3>

                            <ul class="list">
                                <li class="active"><a href="#">Account Dashboard</a></li>
                                <li><a href="#">Change Password</a></li>
                                <li><a href="/home">My Orders</a></li>
                               
                            </ul>
                        </div><!-- End .widget -->
                    </aside><!-- End .col-lg-3 -->
                </div><!-- End .row -->
            </div><!-- End .container -->

            <div class="mb-5"></div><!-- margin -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.final', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/singleorder.blade.php ENDPATH**/ ?>