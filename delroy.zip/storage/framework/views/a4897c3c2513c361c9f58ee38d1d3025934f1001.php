
<?php $__env->startSection('content'); ?>
Create Comission Here

<div class="outer-w3-agile col-xl mt-3">
 <h4 class="tittle-w3-agileits mb-4">Percentage</h4>
 <form action="<?php echo e(route('commision.store')); ?>" method="post"  >
     <?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="exampleFormControlInput1">This is the percentage thats going to be charged on suppliers</label>
    <input type="number" name="percentage" class="form-control" id="exampleFormControlInput1" placeholder="Enter Percentage Here" required=""> 
    </div>
                             
                              
<button class="btn btn-success"type="submit">submit</button>
                             
                            </form>
                        </div>

<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.adminlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/admin/commision/create.blade.php ENDPATH**/ ?>