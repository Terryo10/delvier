
<?php $__env->startSection('content'); ?>

 <nav aria-label="breadcrumb" class="top-nav breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb mt-0">
                        <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="category.html">Categories</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
                    </ol>
                </div><!-- End .container -->
            </nav>
 <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="row row-sm">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="col-6 col-md-4">
                                <div class="product-default">
                                    <figure >
										
										<a href="/product/<?php echo e($item->id); ?>">
                                            <img style="" src="/storage/product_images/<?php echo e($item->firstImage); ?>">
                                        </a>
										
                                        
                                    </figure>
                                    <div class="product-details">
                                        
                                        <h2 class="product-title">
										<a href="/product/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a>
                                        </h2>
                                        <div class="price-box">
										<span class="product-price">$<?php echo e($item->price); ?>.00</span>
                                        </div><!-- End .price-box -->
                                        <div class="product-action">
											 <form  method="post" action="<?php echo e(route('savetocart')); ?>" >
                               					 <?php echo csrf_field(); ?>
													<div>
														
													<div class="product-single-qty">
													<div class="input-group">
														<span class="input-group-btn">
																<button onclick="increment(<?php echo e($item->id); ?>)" type="button" class="quantity-right-plus btn btn-success btn-number" data-type="plus" data-field="">
																	+
																</button>
															</span>
														<input type="number" id="quantity<?php echo e($item->id); ?>" name="quantity" class="" value="1"s min="1" max="100" required="">
															<span class="input-group-btn">
																<button onclick="decrement(<?php echo e($item->id); ?>)" type="button" class="quantity-left-minus btn btn-danger btn-number"  data-type="minus" data-field="">
															-
																</button>
															</span>
													</div>
                        							</div>
														
														<input type="hidden" value="<?php echo e($item->price); ?>" name="price" >
														<input type="hidden" value="<?php echo e($item->id); ?>" name="product_id">
													</div><br>

                            						<div class="emply-btns">
                                
                                					<button type="submit" class="btn-icon btn-add-cart"><i class="icon-bag"></i>ADD TO CART</button>
                            						</div>

                            						</form>
                                          
                                        </div>
                                    </div><!-- End .product-details -->
                                </div>
							</div> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                           
                        </div>

                        <nav class="toolbox toolbox-pagination">
                            <div class="toolbox-item toolbox-show">
                                <label>Showing 1–9 of 60 results</label>
                            </div><!-- End .toolbox-item -->

                            <ul class="pagination">
                                <li class="page-item disabled">
                                    <a class="page-link page-link-btn" href="#"><i class="icon-angle-left"></i></a>
                                </li>
                                <li class="page-item active">
                                    <a class="page-link" href="#">1 <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item"><a class="page-link" href="#">4</a></li>
                                <li class="page-item"><span>...</span></li>
                                <li class="page-item"><a class="page-link" href="#">15</a></li>
                                <li class="page-item">
                                    <a class="page-link page-link-btn" href="#"><i class="icon-angle-right"></i></a>
                                </li>
                            </ul>
                        </nav>
                    </div><!-- End .col-lg-9 -->

                    <aside class="sidebar-shop col-lg-3 order-lg-first">
                         <div class="sidebar-wrapper">
                            <div class="widget">
                                <h3 class="widget-title">
                                    <a data-toggle="collapse" href="#widget-body-1" role="button" aria-expanded="true" aria-controls="widget-body-1">More Categories</a>
                                </h3>

                                <div class="collapse show" id="widget-body-1">
                                    <div class="widget-body">
                                        <ul class="cat-list">
											<?php $__currentLoopData = $categoryese; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><a href="/categories/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        
                                        </ul>
                                    </div><!-- End .widget-body -->
                                </div><!-- End .collapse -->
                            </div><!-- End .widget -->

                    
                        

                            <div class="widget widget-block">
                                <h3 class="widget-title">Get More From Delvier</h3>
                                <h5>Buy & Get Your products Delivered.</h5>
                                
                            </div><!-- End .widget -->
                        </div><!-- End .sidebar-wrapper -->
                    </aside><!-- End .col-lg-3 -->
                </div><!-- End .row -->
            </div><!-- End .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.final', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/singlecategory.blade.php ENDPATH**/ ?>