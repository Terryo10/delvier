
<?php $__env->startSection('content'); ?>

<div class="container">
    <div>
<h1>Search Results</h1>
<p> <?php echo e($products->count()); ?>Results for <?php echo e(request()->input('query')); ?></p>
    </div>

<h5>Property Overview:</h5>
<!-- Properties Overview -->
<div class="properties-overview">
<div class="">
<?php if($products->count() == 0): ?>
 <h1> no results found for <?php echo e(request()->input('query')); ?>


<?php else: ?>
            <div class="row row-sm product-ajax-grid">
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md-4">
                                <div class="product-default">
                                    <figure >
										
										<a href="/product/<?php echo e($item->id); ?>">
                                            <img style="" src="storage/product_images/<?php echo e($item->firstImage); ?>">
                                        </a>
										
                                        
                                    </figure>
                                    <div class="product-details">
                                        <div class="ratings-container">
                                           
                                        </div><!-- End .product-container -->
                                        <h2 class="product-title">
										<a href="/product/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a>
                                        </h2>
                                        <div class="price-box">
										<span class="product-price">$<?php echo e($item->price); ?>.00</span>
                                        </div><!-- End .price-box -->
                                        <div class="product-action">
											 <form  method="post" action="<?php echo e(route('savetocart')); ?>" >
                               					 <?php echo csrf_field(); ?>
													<div>
														
													<div class="product-single-qty">
													<div class="input-group">
														<span class="input-group-btn">
																<button onclick="increment(<?php echo e($item->id); ?>)" type="button" class="quantity-right-plus btn btn-success btn-number" data-type="plus" data-field="">
																	+
																</button>
															</span>
														<input type="number" id="quantity<?php echo e($item->id); ?>" name="quantity" class="" value="1"s min="1" max="100" required="">
															<span class="input-group-btn">
																<button onclick="decrement(<?php echo e($item->id); ?>)" type="button" class="quantity-left-minus btn btn-danger btn-number"  data-type="minus" data-field="">
															-
																</button>
															</span>
													</div>
                        							</div>
														
														<input type="hidden" value="<?php echo e($item->price); ?>" name="price" >
														<input type="hidden" value="<?php echo e($item->id); ?>" name="product_id">
													</div><br>

                            						<div class="emply-btns">
                                
                                					<button type="submit" class="btn-icon btn-add-cart"><i class="icon-bag"></i>ADD TO CART</button>
                            						</div>

                            						</form>
                                          
                                        </div>
                                    </div><!-- End .product-details -->
                                </div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>               
<?php endif; ?>
                                   
                                    
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.final', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/search-results.blade.php ENDPATH**/ ?>