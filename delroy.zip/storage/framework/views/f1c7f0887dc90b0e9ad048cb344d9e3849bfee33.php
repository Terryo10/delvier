
<?php $__env->startSection('content'); ?>
 <!-- main-heading -->
            <h2 class="main-title-w3layouts mb-2 text-center">Users</h2>
            <!--// main-heading -->
                <ul class="prof-widgt-content">
                            <li class="menu">
                                <ul>
                                    <li class="button">
                                        <a href="#">
                                            <i class="fas fa-envelope"></i> USERS ACTIONS
                                        </a>
                                    </li>
                                    <li class="dropdown">
                                        <ul class="icon-navigation">
                                            <li>
                                                <a href="/category/create">View Blocked
                                                    <span class="float-right"></span>
                                                </a>
                                            </li>
                                            
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
 <!-- table3 -->
                <div class="outer-w3-agile mt-3">
                    <h4 class="tittle-w3-agileits mb-4">all Users</h4>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">User Name</th>
                               
                                 <th scope="col">Email</th>
                                  <th scope="col">Action</th>
                                 <th scope="col">Role</th>
                                 <th scope="col">Action</th>
                                 
                                 
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <th scope="row"><?php echo e($items->name); ?></th>
                            <th scope="row"><?php echo e($items->email); ?></th>
                            <?php if($items->role == 1): ?>
                                <th scope="row">Supplier</th>
                            <?php elseif($items->role == 10): ?>
                                <th scope="row">ADMIN</th>
                            <?php else: ?>
                                <th scope="row">General User</th>
                            <?php endif; ?>
                            
                            <td><a href="/user/<?php echo e($items->id); ?>"><button  class="btn btn-primary" >Edit User Role</button></a></td>
                            <td><a href="/userview/<?php echo e($items->id); ?>"><button  class="btn btn-success" >View </button></a> </td>
                           

                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!--// table3 -->

  

                <script>
                    $(document).ready(function(){

                         $('.delete_form').on ('submit', function(){
                    if(confirm("are you sure you want to delete it ?"))
                    {
                        return true;
                    }
                    else{
                        return false;
                    }
                });

                    });
               
                </script>
                  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/admin/users/index.blade.php ENDPATH**/ ?>