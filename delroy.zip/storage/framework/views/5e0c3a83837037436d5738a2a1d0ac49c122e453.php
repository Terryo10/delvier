
<?php $__env->startSection('content'); ?>
   

    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('usersm.update',$user->id)); ?>">
      <?php echo e(method_field('PATCH')); ?>

      <?php echo e(csrf_field()); ?>

            <div class="form-group">
               <div class="form-group">
          <label for="exampleFormControlSelect2"> Current user role is 
              <?php if($user->role == 10): ?>
                    Admin
              <?php elseif($user->role == 1): ?>
                    Supplier
              <?php else: ?>
                    General User
              <?php endif; ?>
            </label><br>
        <label for="exampleFormControlSelect2"> Role select</label>
        <select name="role" multiple class="form-control" id="exampleFormControlSelect2">
       <option value="0">General User</option>
        <option value="1">Supplier</option>
         <option value="10">Admin</option>
       

        </select>
        </div>
        <div>
            <button class="btn btn-primary" type="submit">Update</button>
        </div>
            </div>
        <hr>
       
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>