
<?php $__env->startSection('content'); ?>
	<section>
		<div class="block">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="heading">
							<h2>Featured Categories</h2>
							<span>Filter Products With The Category Of Your Choice</span>
						</div><!-- Heading -->
						<div class="job-listings-sec">
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="job-listing">
								<div class="job-title-sec">
									<div class="c-logo"> <img src="" alt="" /> </div>
                                <h3><a href="#" title=""><?php echo e($item->name); ?></a></h3>
									
								</div>
								<span class="job-lctn"><i class="la la-shopping-cart"></i>Category</span>
								
                            <span class="job-is ft" ><a href="/category/<?php echo e($item->id); ?>">(<?php echo e($item->products->count()); ?>) Products</a></span>
							</div><!-- Job -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						
						</div>
					</div>
					<div class="col-lg-12">
						<div class="browse-all-cat">
							<a href="#" title="">Load more listings</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.final', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/category.blade.php ENDPATH**/ ?>