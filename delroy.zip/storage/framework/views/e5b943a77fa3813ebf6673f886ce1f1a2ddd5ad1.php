
<?php $__env->startSection('content'); ?>
<!-- main-heading -->
<h2 class="main-title-w3layouts mb-2 text-center">Create Product</h2>
            <!--// main-heading -->
                <!-- Forms-2 -->
                        <div class="outer-w3-agile col-xl mt-3">
                            <h4 class="tittle-w3-agileits mb-4">Form Controls</h4>
                            <form action="<?php echo e(route('product.store')); ?>" method="post"  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Product Name</label>
                                    <input name="name" type="text" class="form-control" id="exampleFormControlInput1" placeholder="" required=""> 
                                </div>
                                <div class="form-group">
                                     <input name="shop_id" type="hidden" value="<?php echo e($shops->id); ?>" class="form-control" id="exampleFormControlInput1" placeholder="" required=""> 
                                   
                                    
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect2"> Category select</label>
                                    <select name="category_id" multiple class="form-control" id="exampleFormControlSelect2">
                                       <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                  <div class="form-group">
                                    <label for="exampleFormControlInput1">Price</label>
                                    <input type="number" name="price" class="form-control" id="exampleFormControlInput1" placeholder="" required=""> 
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Quantity</label>
                                    <input type="number" name="qty" class="form-control" id="exampleFormControlInput1" placeholder="" required=""> 
                                </div>
                                <br>
                                 <label for="exampleFormControlInput1">Product Face Image</label>
                                 <br>
                                <div class="control-group input-group" style="margin-top:10px">
                                   
                                  <input type="file" name="firstImage" id="fileToUpload">
                                  
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Description</label>
                                    <textarea name="description"class="form-control" id="exampleFormControlTextarea1" rows="3" required=""></textarea>
                                </div>
                                <br>
                                <label for="exampleFormControlTextarea1">Complementing image</label><br>
                                <div class="input-group control-group increment" >
                                    
                                    <input type="file" name="image[]" class="form-control">
                                    <div class="input-group-btn"> 
                                        <button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
                                </div>
                                </div>
                               <div class="clone hide">
                                <div class="control-group input-group" style="margin-top:10px">
                                    <input type="file" name="image[]" class="form-control">
                                    <div class="input-group-btn"> 
                                    <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
                                    </div>
                                </div>
                                </div>
                                <div>
                                <button type="submit" class="btn btn-primary">Submit to system</button>
                                </div>
                           

                                
                            </form>
                        </div>
                        <!--// Forms-2 -->


    <script type="text/javascript">

    $(document).ready(function() {

      $(".btn-success").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.supply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/supplier/products/create.blade.php ENDPATH**/ ?>