
<?php $__env->startSection('content'); ?>
  <!-- main-heading -->
<h2 class="main-title-w3layouts mb-2 text-center"><?php echo e($shop->name); ?></h2>
            <!--// main-heading -->
                <ul class="prof-widgt-content">
                            <li class="menu">
                                <ul>
                                    <li class="button">
                                        <a href="#">
                                            <i class="fas fa-envelope"></i> SHOP ACTIONS
                                        </a>
                                    </li>
                                    <li class="dropdown">
                                        <ul class="icon-navigation">
                                          
                                        
                                                 <li>
                                                <a href="/product/create">Create Product
                                                    <span class="float-right"></span>
                                                </a>
                                         
                                           
                                          
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                          

                     <div class="outer-w3-agile mt-3">
                    <h4 class="tittle-w3-agileits mb-4">all Products</h4>
                    <div class="form-group">
                    <input class="form-control" type="text" id="myInput" onkeyup="myFunction()" placeholder="Search Products..">
                    </div>
                    <table class="table table-striped" id="myTable">
                        <thead>
                        <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Price</th>
                                <th scope="col">Action</th>
                                <th scope="col">Admin approval</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td scope="row"><?php echo e($items->name); ?></td>
                            <td>$<?php echo e($items->price); ?>.00</td>
                       
                            <td><a href="/product/<?php echo e($items->id); ?>/edit"><button class="btn btn-danger">Edit Product</button></a></td>
                            
                            <td><?php if($items->adminApproval == 1): ?>
                                Approved

                                <?php else: ?>
                                DissApproved 
                            <?php endif; ?>
                        </td>
                            
                            
                            <td><a href="/product/<?php echo e($items->id); ?>"><button class="btn btn-success">View Product</button></a></td>

                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!--// table3 -->

                <script>
                    $(document).ready(function(){

                         $('.delete_form').on ('submit', function(){
                    if(confirm("are you sure you want to delete it ?"))
                    {
                        return true;
                    }
                    else{
                        return false;
                    }
                });

                    });
               
                </script>

                <script>
    function myFunction() {
    // Declare variables
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");

    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[0];
        if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
        } else {
            tr[i].style.display = "none";
        }
        }
    }
    }
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.supply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/supplier/shops/show.blade.php ENDPATH**/ ?>