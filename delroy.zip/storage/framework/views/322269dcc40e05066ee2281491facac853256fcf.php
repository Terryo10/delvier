<?php $__env->startSection('content'); ?>
       <div class="features-section">
                <div class="container">
                    <h2 class="subtitle">My Orders</h2>
                    <div class="row">
						<?php if($orders->count() > 0): ?>									      
						<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="feature-box">
                                <i class="icon-cart"></i>

                                <div class="feature-box-content">
                                    <h3>ORDER REF: <?php echo e($item->id); ?></h3>
									<p>
									 CREATED ON: <?php echo e($item->created_at); ?><br>
									 PAYMENT STATUS: <?php echo e($item->paymentStatus); ?><br>
									 TRANSACTION REF: <?php echo e($item->transaction_ref); ?>

									</p>
								</div><!-- End .feature-box-content -->
								<a href="/single_order/<?php echo e($item->id); ?>" class="btn btn-block btn-sm btn-primary">View Order</a>
							</div><!-- End .feature-box -->
							  
						</div><!-- End .col-lg-4 -->
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						    <div class="col-lg-12">
                            <div class="feature-box">
                                <i class="icon-cart"></i>

                                <div class="feature-box-content">
                                <h3>YOU DONT HAVE ORDERS YET</h3>
                                   

                                </div><!-- End .feature-box-content -->
                                <br>
                                <div class="checkout-methods">
                                <a href="/shopping" class="btn btn-block btn-sm btn-primary">START SHOPPING</a>
                            </div><!-- End .checkout-methods -->
                            </div><!-- End .feature-box -->
                        </div><!-- End .col-lg-4 -->
					</div><!-- End .row -->
					
					
				</div><!-- End .container -->
				<?php endif; ?>
            </div><!-- End .features-section -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.final', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\delroy\resources\views/home.blade.php ENDPATH**/ ?>